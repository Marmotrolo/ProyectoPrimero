package dam.primero.dao;

import dam.primero.modelos.Participante;
import dam.primero.modelos.ParticipanteIndividual;
import dam.primero.modelos.Grupo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParticipanteDaoImpl {
    private JdbcDao jdbcdao;

    public ParticipanteDaoImpl() throws Exception {
        jdbcdao = new JdbcDao(); // Inicializa la conexión a la base de datos
    }

    // 1. Insertar participante individual
    public boolean insertarIndividual(ParticipanteIndividual p) throws SQLException {
        String sql = "INSERT INTO Participantes (nombre_completo, curso, tipo) VALUES (?, ?, 'INDIVIDUAL')";
        
        try (Connection conn = jdbcdao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, p.getNombre());
            stmt.setString(2, p.getCurso());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Error al insertar participante individual");
            }
            
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    p.setId(rs.getInt(1));
                }
            }
            return true;
        }
    }

    // 2. Insertar grupo con 5 miembros
    public boolean insertarGrupo(Grupo grupo) throws SQLException {
        if (grupo.getMiembros().size() != 5) {
            throw new SQLException("Debe haber exactamente 5 miembros en el grupo");
        }
        
        Connection conn = null;
        try {
            conn = jdbcdao.getConnection();
            conn.setAutoCommit(false);
            
            // Insertar el grupo
            String sqlGrupo = "INSERT INTO Participantes (nombre_grupo, curso, tipo) VALUES (?, ?, 'GRUPO')";
            int grupoId;
            
            try (PreparedStatement stmt = conn.prepareStatement(sqlGrupo, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, grupo.getNombreGrupo());
                stmt.setString(2, grupo.getCurso());
                stmt.executeUpdate();
                
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        grupoId = rs.getInt(1);
                        grupo.setId(grupoId);
                    } else {
                        throw new SQLException("Error al obtener ID del grupo");
                    }
                }
            }
            
            // Insertar miembros
            String sqlMiembro = "INSERT INTO Participantes (nombre_completo, curso, tipo) VALUES (?, ?, 'INDIVIDUAL')";
            for (ParticipanteIndividual miembro : grupo.getMiembros()) {
                try (PreparedStatement stmt = conn.prepareStatement(sqlMiembro, Statement.RETURN_GENERATED_KEYS)) {
                    stmt.setString(1, miembro.getNombre());
                    stmt.setString(2, grupo.getCurso());
                    stmt.executeUpdate();
                    
                    try (ResultSet rs = stmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            miembro.setId(rs.getInt(1));
                        }
                    }
                }
            }
            
            conn.commit();
            return true;
            
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) conn.setAutoCommit(true);
        }
    }

    // 3. Buscar participantes por curso
    public List<Participante> buscarPorCurso(String curso) throws SQLException {
        List<Participante> resultados = new ArrayList<>();
        String sql = "SELECT * FROM Participantes WHERE curso = ?";
        
        try (Connection conn = jdbcdao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, curso);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    if (rs.getString("tipo").equals("INDIVIDUAL")) {
                        resultados.add(new ParticipanteIndividual(
                            rs.getInt("id"),
                            rs.getString("nombre_completo"),
                            rs.getString("curso")
                        ));
                    } else {
                        Grupo grupo = new Grupo();
                        grupo.setId(rs.getInt("id"));
                        grupo.setNombreGrupo(rs.getString("nombre_grupo"));
                        grupo.setCurso(rs.getString("curso"));
                        grupo.setMiembros(obtenerMiembrosGrupo(grupo.getId()));
                        resultados.add(grupo);
                    }
                }
            }
        }
        return resultados;
    }

    // 4. Modificar participante o grupo
    public boolean actualizar(Participante p) throws SQLException {
        if (p instanceof ParticipanteIndividual) {
            String sql = "UPDATE Participantes SET nombre_completo = ?, curso = ? WHERE id = ? AND tipo = 'INDIVIDUAL'";
            try (Connection conn = jdbcdao.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                
                stmt.setString(1, ((ParticipanteIndividual) p).getNombre());
                stmt.setString(2, p.getCurso());
                stmt.setInt(3, p.getId());
                
                return stmt.executeUpdate() > 0;
            }
        } else if (p instanceof Grupo) {
            Grupo grupo = (Grupo) p;
            if (grupo.getMiembros().size() != 5) {
                throw new SQLException("El grupo debe tener exactamente 5 miembros");
            }
            
            Connection conn = null;
            try {
                conn = jdbcdao.getConnection();
                conn.setAutoCommit(false);
                
                // Actualizar datos del grupo
                String sqlGrupo = "UPDATE Participantes SET nombre_grupo = ?, curso = ? WHERE id = ? AND tipo = 'GRUPO'";
                try (PreparedStatement stmt = conn.prepareStatement(sqlGrupo)) {
                    stmt.setString(1, grupo.getNombreGrupo());
                    stmt.setString(2, grupo.getCurso());
                    stmt.setInt(3, grupo.getId());
                    stmt.executeUpdate();
                }
                
                // Actualizar miembros
                String sqlMiembro = "UPDATE Participantes SET nombre_completo = ?, curso = ? WHERE id = ? AND tipo = 'INDIVIDUAL'";
                for (ParticipanteIndividual miembro : grupo.getMiembros()) {
                    try (PreparedStatement stmt = conn.prepareStatement(sqlMiembro)) {
                        stmt.setString(1, miembro.getNombre());
                        stmt.setString(2, grupo.getCurso());
                        stmt.setInt(3, miembro.getId());
                        stmt.executeUpdate();
                    }
                }
                
                conn.commit();
                return true;
                
            } catch (SQLException e) {
                if (conn != null) conn.rollback();
                throw e;
            } finally {
                if (conn != null) conn.setAutoCommit(true);
            }
        }
        return false;
    }

    // Método auxiliar para obtener miembros de un grupo
    private List<ParticipanteIndividual> obtenerMiembrosGrupo(int grupoId) throws SQLException {
        List<ParticipanteIndividual> miembros = new ArrayList<>();
        String sql = "SELECT p.* FROM Participantes p JOIN Grupo_Miembros gm ON p.id = gm.miembro_id WHERE gm.grupo_id = ?";
        
        try (Connection conn = jdbcdao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, grupoId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    miembros.add(new ParticipanteIndividual(
                        rs.getInt("id"),
                        rs.getString("nombre_completo"),
                        rs.getString("curso")
                    ));
                }
            }
        }
        return miembros;
    }
}
